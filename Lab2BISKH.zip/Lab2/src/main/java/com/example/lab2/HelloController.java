package com.example.lab2;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;
import java.sql.*;

public class HelloController implements Initializable {
    public TableView<Customer> CustomerTable;
    public TableColumn<Customer,Integer> Cid;
    public TableColumn <Customer,String> CustomerName;
    public TableColumn <Customer,String> Country;
    public TableColumn <Customer,Integer> Phone;
    public TextField cid;
    public TextField CCustomerName;
    public TextField CCountry;
    public TextField CPhone;
    @FXML
    private Label welcomeText;

    ObservableList<Customer> list = FXCollections.observableArrayList();

    @FXML
    protected void onHelloButtonClick() {
        loadData();
    }

    private void loadData() {
        list.clear();

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM person_details";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int Cid = resultSet.getInt("Cid");
                String CustomerName = resultSet.getString("CustomerName");
                String Country = resultSet.getString("Country");
                int Phone = resultSet.getInt("Phone");
                CustomerTable.getItems().add(new Customer(Cid, CustomerName, Country, Phone));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        Cid.setCellValueFactory(new PropertyValueFactory<Customer,Integer>("Cid"));
        CustomerName.setCellValueFactory(new PropertyValueFactory<Customer,String>("CustomerName"));
        Country.setCellValueFactory(new PropertyValueFactory<Customer,String>("Country"));
       Phone.setCellValueFactory(new PropertyValueFactory<Customer,Integer>("Phone"));
        CustomerTable.setItems(list);


    }

    public void InsertData(ActionEvent actionEvent) {



        String CustomerName = CCustomerName.getText();
        String Country = CCountry.getText();
        String Phone = CPhone.getText();




        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "INSERT INTO `person_details`( `CustomerName`, `Country`, `Phone`) VALUES ('"+CustomerName+"','"+Country+"','"+Phone+"')";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    public void UpdateData(ActionEvent actionEvent) {
        String id = cid.getText();
        String CustomerName = CCustomerName.getText();
        String Country = CCountry.getText();
        String Phone = CPhone.getText();




        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "UPDATE `person_details` SET `CustomerName`='"+CustomerName+"',`Country`='"+Country+"',`Phone`='"+Phone+"' WHERE Cid='"+id+"' ";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void DeleteData(ActionEvent actionEvent) {

        String id = cid.getText();


        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "DELETE FROM `person_details` WHERE Cid='"+id+"'";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void LoadData(ActionEvent actionEvent) {

        String id = cid.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM person_details WHERE Cid='"+id+"'";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {

                String CustomerName = resultSet.getString("CustomerName");
                String Country= resultSet.getString("Country");
                String Phone = resultSet.getString("Phone");

                CCustomerName.setText(CustomerName);
                CCountry.setText(Country);
                CPhone.setText(Phone);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}