package com.example.lab2;
public class Customer {

    private int Cid;
    private String CustomerName;

    private String Country;

    private int Phone;

    public Customer(int Cid, String CustomerName, String Country, int Phone) {
        this.Cid = Cid;
        this.CustomerName = CustomerName;
        this.Country = Country;
        this.Phone = Phone;
    }

    public int getCid() {
        return Cid;
    }

    public void setCid(int Cid) {
        this.Cid = Cid;
    }

    public String getCustomerName() {
        return CustomerName;
    }

    public void setCustomerName(String CustomerName) {
        this.CustomerName = CustomerName;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }

    public int getPhone() {
        return Phone;
    }

    public void setPhone(int Phone) {
        this.Phone= Phone;
    }
}
